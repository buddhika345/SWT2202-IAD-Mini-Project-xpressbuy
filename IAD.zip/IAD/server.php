<?php 
$name="";
$address="";
$phone="";
$email="";
$password="";
$id=0;
$edit_state=false;
$db=mysqli_connect('localhost','root','','iad_form_project');

if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$address=$_POST['address'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$duplicate=mysqli_query($db,"SELECT * FROM info WHERE name='$name' AND email='$email' AND  password='$password'");
    if(mysqli_num_rows($duplicate) < 0){
        echo 
        "<script>alert('username and email already taken');</script>";
        header('location:index.php');
    }
    else{
    $query="INSERT INTO info(name,address,phone,email,password)VALUES('$name','$address','$phone','$email','$password')";
	mysqli_query($db,$query);
	echo 
		"<script>alert('Signup successfully');</script>";
		header('location:home.html');

   }
}
?>