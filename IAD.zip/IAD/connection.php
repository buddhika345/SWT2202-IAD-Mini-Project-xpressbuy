<?php 
$email="";
$id="";
$db=mysqli_connect('localhost','root','','project_email');

if(isset($_POST['submit'])){
	$email=$_POST['email'];
	$query="INSERT INTO info(email)VALUES('$email')";
	mysqli_query($db,$query);
	header('location:index.html');
}

?>